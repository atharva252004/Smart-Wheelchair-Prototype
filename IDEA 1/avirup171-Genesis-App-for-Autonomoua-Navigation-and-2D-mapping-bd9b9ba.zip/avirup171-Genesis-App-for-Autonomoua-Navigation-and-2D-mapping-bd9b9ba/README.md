# Genesis-App-for-Autonomoua-Navigation-and-2D-mapping
The app that can be used for 2D mapping

This is related to 2D mapping of an unknown indoor environment.
Clone this and modify and use it. This is a part of my project on autonomous navigation
